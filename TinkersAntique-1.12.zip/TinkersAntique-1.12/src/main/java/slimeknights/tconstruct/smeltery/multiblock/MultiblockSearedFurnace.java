package slimeknights.tconstruct.smeltery.multiblock;

import net.minecraft.block.BlockSlab;
import net.minecraft.block.BlockStairs;
import net.minecraft.block.state.IBlockState;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

import slimeknights.tconstruct.smeltery.TinkerSmeltery;
import slimeknights.tconstruct.smeltery.tileentity.TileSearedFurnace;

public class MultiblockSearedFurnace extends MultiblockTinker {

  public boolean hasTank;

  public MultiblockSearedFurnace(TileSearedFurnace furnace) {
    // perfect cubes only
    super(furnace, true, true, true);
  }

  // we need a tank bro
  @Override
  public MultiblockStructure detectMultiblock(World world, BlockPos center, int limit) {
    hasTank = false;
    MultiblockStructure ret = super.detectMultiblock(world, center, limit);
    if(!hasTank) {
      return null;
    }
    return ret;
  }

  @Override
  public boolean isValidBlock(World world, BlockPos pos) {
    // controller always is valid
    if(pos.equals(tile.getPos())) {
      return true;
    }

    // only seared blocks in the main structure
    return world.getBlockState(pos).getBlock() == TinkerSmeltery.searedBlock && isValidSlave(world, pos);
  }

  @Override
  public boolean isCeilingBlock(World world, BlockPos pos) {
    // controller always is valid
    if(pos.equals(tile.getPos())) {
      return true;
    }

    if(!isValidSlave(world, pos)) {
      return false;
    }

    // allow stairs and slabs, but need to be the bottom side
    IBlockState state = world.getBlockState(pos);
    if(state.getBlock() instanceof BlockSlab && state.getValue(BlockSlab.HALF) == BlockSlab.EnumBlockHalf.TOP) {
      return false;
    }
    if(state.getBlock() instanceof BlockStairs && state.getValue(BlockStairs.HALF) == BlockStairs.EnumHalf.TOP) {
      return false;
    }

    return TinkerSmeltery.searedStairsSlabs.contains(state.getBlock());
  }

  @Override
  public boolean isFrameBlock(World world, BlockPos pos, EnumFrameType type) {
    // controller always is valid
    if(pos.equals(tile.getPos())) {
      return true;
    }

    if(!isValidSlave(world, pos)) {
      return false;
    }

    // we need a tank, but they are only valid in the frame
    IBlockState state = world.getBlockState(pos);
    if(state.getBlock() == TinkerSmeltery.searedTank) {
      hasTank = true;
      return true;
    }

    // anything is allowed on the ceiling and floor of the frame, just the walls matter
    if(type != EnumFrameType.WALL) {
      return true;
    }

    // the above also allows slabs and stairs on the ceiling, so no need to add it here
    return state.getBlock() == TinkerSmeltery.searedBlock;
  }
}
